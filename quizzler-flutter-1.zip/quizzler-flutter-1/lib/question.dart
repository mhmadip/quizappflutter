class Question {
  String questionText;
  bool questionAnswer;
  //Syntactic Sugar
  Question([this.questionText, this.questionAnswer]);

  // Constructor
  // Question(String q, bool a) {
  //   questionText = q;
  //   questionAnswer = a;
  // }
}
